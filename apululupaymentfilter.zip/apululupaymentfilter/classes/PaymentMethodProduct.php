<?php
class PaymentMethodProduct extends ObjectModel
{
    public $id_payment_method_product;
    public $id_product;
    public $payment_method;

    public static $definition = [
        'table' => 'payment_method_product',
        'primary' => 'id_payment_method_product',
        'fields' => [
            'id_product' => ['type' => self::TYPE_INT, 'required' => true],
            'payment_method' => ['type' => self::TYPE_STRING, 'required' => true],
        ],
    ];

    public static function getMethods()
    {
        return ['tropipay', 'ps_cashondelivery', 'cheque'];
    }

    public static function getProductMethods($id_product)
    {
        return Db::getInstance()->executeS('SELECT payment_method FROM '._DB_PREFIX_.'payment_method_product WHERE id_product = '.(int)$id_product);
    }

    public static function setProductMethods($id_product, $methods)
    {
        Db::getInstance()->delete('payment_method_product', 'id_product = '.(int)$id_product);
        foreach ($methods as $method) {
            $obj = new PaymentMethodProduct();
            $obj->id_product = (int)$id_product;
            $obj->payment_method = pSQL($method);
            $obj->add();
        }
    }
}
