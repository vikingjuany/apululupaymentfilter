<?php
require_once _PS_MODULE_DIR_.'apululupaymentfilter/classes/PaymentMethodProduct.php';

class AdminApululuPaymentFilterController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        parent::__construct();
    }

    public function initContent()
    {
        parent::initContent();

        $products = Product::getProducts($this->context->language->id, 0, 1000, 'id_product', 'ASC', false, false);
        foreach ($products as &$product) {
            $product['methods'] = array_column(PaymentMethodProduct::getProductMethods($product['id_product']), 'payment_method');
        }

        $this->context->smarty->assign([
            'products' => $products,
            'methods' => PaymentMethodProduct::getMethods(),
            'token' => Tools::getAdminTokenLite('AdminModules'),
        ]);

        $this->setTemplate('products.tpl');
    }

    public function postProcess()
    {
        if (Tools::isSubmit('submitFilter')) {
            $methods = Tools::getValue('methods');
            foreach ($methods as $id_product => $product_methods) {
                PaymentMethodProduct::setProductMethods((int)$id_product, $product_methods);
            }

            Tools::redirectAdmin($this->context->link->getAdminLink('AdminApululuPaymentFilter').'&conf=4');
        }
    }
}
