<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

require_once dirname(__FILE__).'/classes/PaymentMethodProduct.php';

class Apululupaymentfilter extends Module
{
    public function __construct()
    {
        $this->name = 'apululupaymentfilter';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = 'Juany';
        $this->need_instance = 0;
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Payment Method Filter');
        $this->description = $this->l('Filter products by selected payment method after login.');
    }

    public function install()
    {
        return parent::install()
            && $this->registerHook('displayFooter')
            && $this->registerHook('actionCustomerAccountAdd')
            && $this->registerHook('actionCustomerLoginAfter')
            && $this->installDB();
    }

    public function installDB()
    {
        return Db::getInstance()->execute(
            "CREATE TABLE IF NOT EXISTS `"._DB_PREFIX_."payment_method_product` (
                `id_payment_method_product` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `id_product` INT UNSIGNED NOT NULL,
                `payment_method` VARCHAR(255) NOT NULL,
                PRIMARY KEY (`id_payment_method_product`)
            ) ENGINE="._MYSQL_ENGINE_." DEFAULT CHARSET=utf8;"
        );
    }

    public function uninstall()
    {
        return Db::getInstance()->execute("DROP TABLE IF EXISTS `"._DB_PREFIX_."payment_method_product`")
            && parent::uninstall();
    }

    public function getContent()
    {
        Tools::redirectAdmin($this->context->link->getAdminLink('AdminApululuPaymentFilter'));
    }

    public function hookDisplayFooter($params)
    {
        if (!$this->context->customer->isLogged()) {
            return '';
        }

        $script = '<script>
            if (!sessionStorage.getItem("apululupaymentfilter")) {
                $("#apululupaymentfilter-modal").modal({backdrop: "static", keyboard: false});
            }
        </script>';

        $this->context->controller->addCSS($this->_path.'views/templates/admin/modal.css');
        $this->context->controller->addJS($this->_path.'views/templates/admin/modal.js');

        $this->context->smarty->assign([
            'module_path' => $this->_path
        ]);

        return $this->display(__FILE__, 'views/templates/admin/modal.tpl') . $script;
    }
}
